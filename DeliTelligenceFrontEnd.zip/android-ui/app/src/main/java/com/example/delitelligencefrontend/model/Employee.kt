package com.example.delitelligencefrontend.model


data class Employee(
    val employeeFirstName: String,
    val employeeLastName: String,
    val hireDate: String
)
