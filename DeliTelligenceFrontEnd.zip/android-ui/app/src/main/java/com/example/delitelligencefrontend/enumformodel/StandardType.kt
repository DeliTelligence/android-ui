package com.example.delitelligencefrontend.enumformodel

enum class StandardType {
    FILLING,
    SALAD,
}