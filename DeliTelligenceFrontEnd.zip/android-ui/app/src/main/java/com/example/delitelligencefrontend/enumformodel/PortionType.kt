package com.example.delitelligencefrontend.enumformodel

enum class PortionType {
    SALAD,
    FILLING,
    QUANTITY
}