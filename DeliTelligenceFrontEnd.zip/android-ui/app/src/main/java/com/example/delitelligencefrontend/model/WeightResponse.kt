package com.example.delitelligencefrontend.model

data class WeightResponse(
    val weight: Double
)
