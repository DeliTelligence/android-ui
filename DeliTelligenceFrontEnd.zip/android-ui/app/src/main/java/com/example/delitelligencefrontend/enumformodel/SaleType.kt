package com.example.delitelligencefrontend.enumformodel

enum class SaleType {
    COLD_FOOD,
    HOT_FOOD,
    SALAD

}