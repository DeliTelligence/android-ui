package com.example.delitelligencefrontend.model

data class StandardWeight(
    val standardType: String?
)
