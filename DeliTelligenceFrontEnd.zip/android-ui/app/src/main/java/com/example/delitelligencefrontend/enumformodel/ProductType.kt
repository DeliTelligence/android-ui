package com.example.delitelligencefrontend.enumformodel

enum class ProductType {
    HOT_FOOD,
    COLD_FOOD,
    BREAD;


}