package com.example.delitelligencefrontend.model

data class StatusResponse(
    val status: String
)