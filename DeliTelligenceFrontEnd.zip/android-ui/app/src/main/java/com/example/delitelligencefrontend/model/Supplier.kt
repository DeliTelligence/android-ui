package com.example.delitelligencefrontend.model

data class Supplier(
    val supplierName: String
)
