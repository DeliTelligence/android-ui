package com.example.delitelligencefrontend.model

data class StandardWeightProduct(
    val standardWeight: StandardWeight?,
    val standardWeightValue: Float?
)
