package com.example.delitelligencefrontend.enumformodel

enum class AdjustmentType {
    WASTE,
    DELIVERY,
    OTHER
}